Class Habitacion
  has luz;

Class Objeto;
